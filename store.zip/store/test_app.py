"""TEST_DATABASE_URL=postgresql://user@host/postgres python3 -m unittest test_app

Creates its own throwaway database on that server and drops it afterwards; it never touches existing data.
"""
import base64, http.cookiejar, io, os, re, secrets, sys, threading, unittest, urllib.error, urllib.parse, urllib.request
import psycopg

SERVER = os.environ["TEST_DATABASE_URL"]
NAME = "store_test_" + secrets.token_hex(4)
with psycopg.connect(SERVER, autocommit=True) as s: s.execute(f"CREATE DATABASE {NAME}")
os.environ["DATABASE_URL"] = psycopg.conninfo.make_conninfo(SERVER, dbname=NAME)
os.environ["PAYMENT_DETAILS"] = "Bank of Test, acct 123"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import app

def tearDownModule():
    C.close()
    with psycopg.connect(SERVER, autocommit=True) as s: s.execute(f"DROP DATABASE {NAME} WITH (FORCE)")

app.init()
C = app.db()
def user(uid): return C.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
def stock(pid): return C.execute("SELECT stock FROM products WHERE id=?", (pid,)).fetchone()["stock"]
def product(sku, public, member, qty, members_only=0):
    with C:
        return C.execute("INSERT INTO products(sku,name,retail_cents,wholesale_cents,stock,wholesale_only) VALUES(?,?,?,?,?,?) RETURNING id",
                         (sku, sku.title(), public, member, qty, members_only)).fetchone()["id"]

PENDING = app.create_user(C, "pending@x.com", "password123", "Pete", "+1 619 555 0101", "1 Main St", biz_status="pending")
MEMBER = app.create_user(C, "member@x.com", "password123", "Sam", "+1 619 555 0102", "2 Main St", biz_status="approved")
STAFF = app.create_user(C, "staff@x.com", "password123", "Stella", "+1 619 555 0103", role="staff")
with C: DRIVER = C.execute("INSERT INTO drivers(name,phone) VALUES('Dan','+52 646 123 4567') RETURNING id").fetchone()["id"]
ADDR = ("Name", "+1 619 555 0199", "9 Elm St, San Diego")
JPEG = "data:image/jpeg;base64," + base64.b64encode(b"\xff\xd8\xff\xe0" + b"0" * 64).decode()  # magic bytes are what the server checks


class Rules(unittest.TestCase):
    def tearDown(self): C.conn.rollback()

    def test_cents(self):
        self.assertEqual(app.cents("12.5"), 1250)
        self.assertEqual(app.cents("$0.01"), 1)
        for bad in ("abc", "-1", "NaN", ""):
            with self.assertRaises(ValueError): app.cents(bad)

    def test_only_approved_members_order(self):
        pub, members_only = product("charger", 2999, 1800, 10), product("restricted-a", 1000, 500, 10, 1)
        self.assertNotIn(members_only, [p["id"] for p in app.visible_products(C, user(PENDING))])
        for pid in (pub, members_only):  # registered + deposit pending is not enough
            with self.assertRaises(ValueError): app.place_order(C, user(PENDING), {pid: 1}, *ADDR)
        oid = app.place_order(C, user(MEMBER), {pub: 3, members_only: 4}, *ADDR)
        self.assertEqual(C.execute("SELECT total_cents FROM orders WHERE id=?", (oid,)).fetchone()["total_cents"], 3 * 1800 + 4 * 500)
        self.assertEqual((stock(pub), stock(members_only)), (7, 6))

    def test_oversell_rolls_back_whole_order(self):
        a, b = product("a", 100, 50, 5), product("b", 100, 50, 1)
        with self.assertRaises(ValueError): app.place_order(C, user(MEMBER), {a: 2, b: 2}, *ADDR)
        self.assertEqual((stock(a), stock(b)), (5, 1))

    def test_cancel_restocks_once_and_is_final(self):
        a = product("c", 100, 50, 5)
        oid = app.place_order(C, user(MEMBER), {a: 3}, *ADDR)
        app.update_order(C, STAFF, oid, DRIVER, "cancelled", "due_on_delivery", 0)
        self.assertEqual(stock(a), 5)
        with self.assertRaises(ValueError): app.update_order(C, STAFF, oid, DRIVER, "cancelled", "due_on_delivery", 0)
        self.assertEqual(stock(a), 5)

    def test_pay_on_delivery(self):
        oid = app.place_order(C, user(MEMBER), {product("f", 700, 400, 5): 2}, *ADDR)
        o = C.execute("SELECT payment, collect_cents FROM orders WHERE id=?", (oid,)).fetchone()
        self.assertEqual(tuple(o.values()), ("due_on_delivery", 800))
        with self.assertRaises(ValueError): app.update_order(C, STAFF, oid, DRIVER, "delivered", "due_on_delivery", 800)
        with self.assertRaises(ValueError): app.update_order(C, STAFF, oid, DRIVER, "assigned", "due_on_delivery", 801)
        app.update_order(C, STAFF, oid, DRIVER, "delivered", "paid_transfer", 800)

    def test_delivery_pin(self):
        p = product("pin", 1000, 500, 10)
        oid = app.place_order(C, user(MEMBER), {p: 1}, *ADDR, "", 32.715736, -117.161087)
        o = C.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
        self.assertEqual((round(o["lat"], 6), round(o["lng"], 6)), (32.715736, -117.161087))
        self.assertIn("Maps: https://www.google.com/maps/search/?api=1&query=32.715736%2C-117.161087", app.dispatch_text(o, []))
        no_pin = app.place_order(C, user(MEMBER), {p: 1}, *ADDR)  # pin is optional; typed address is used
        self.assertIn("query=9%20Elm%20St", app.dispatch_text(C.execute("SELECT * FROM orders WHERE id=?", (no_pin,)).fetchone(), []))
        for bad in ((95.0, 10.0), (10.0, 200.0), (10.0, None)):
            with self.assertRaises(ValueError): app.place_order(C, user(MEMBER), {p: 1}, *ADDR, "", *bad)
        self.assertEqual(stock(p), 8)  # rejected orders took no stock

    def test_typed_and_map_address_both_kept(self):
        p = product("two-addr", 1000, 500, 10)
        oid = app.place_order(C, user(MEMBER), {p: 1}, "Sam", "+1 619 555 0102", "245 Market St, back gate, apt 4", "",
                              32.7, -117.1, "245 Market Street, San Diego, California 92101")
        o = C.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
        text = app.dispatch_text(o, [])
        self.assertIn("Address: 245 Market St, back gate, apt 4", text)
        self.assertIn("Map pin address: 245 Market Street, San Diego, California 92101", text)
        same = app.place_order(C, user(MEMBER), {p: 1}, "Sam", "+1", "1 Elm St", "", 32.7, -117.1, "1 elm st ")
        self.assertNotIn("Map pin address", app.dispatch_text(C.execute("SELECT * FROM orders WHERE id=?", (same,)).fetchone(), []))
        no_pin = app.place_order(C, user(MEMBER), {p: 1}, "Sam", "+1", "1 Elm St", "", None, None, "ignored without a pin")
        self.assertIsNone(C.execute("SELECT pin_address FROM orders WHERE id=?", (no_pin,)).fetchone()["pin_address"])

    def test_driver_message(self):
        oid = app.place_order(C, user(MEMBER), {product("e", 1500, 900, 5): 2}, *ADDR, "Gate code 12")
        o = C.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
        text = app.dispatch_text(o, C.execute("SELECT * FROM order_items WHERE order_id=?", (oid,)).fetchall())
        for want in (f"#ORD-{oid}", "2 x E", "Gate code 12", "Collect: $18.00", "9 Elm St"): self.assertIn(want, text)
        link = app.wa_link("+52 (646) 123-4567", text)
        self.assertTrue(link.startswith("https://wa.me/526461234567?text="))
        self.assertEqual(urllib.parse.unquote(link.split("text=")[1]), text)
        with self.assertRaises(ValueError): app.wa_link("555", text)
        paid = app.dispatch_text({**o, "payment": "paid_cash"}, [])
        self.assertIn("Collect: nothing", paid); self.assertNotIn("Collect: $", paid)


class Wsgi(unittest.TestCase):
    def call(self, method, path, body=b"", cookie=""):
        got = {}
        env = {"REQUEST_METHOD": method, "PATH_INFO": path.split("?")[0], "QUERY_STRING": path.partition("?")[2],
               "CONTENT_LENGTH": str(len(body)), "wsgi.input": io.BytesIO(body), "HTTP_COOKIE": cookie}
        out = b"".join(app.app(env, lambda status, headers: got.update(status=status, headers=headers)))
        return got["status"], dict(got["headers"]), out.decode()

    def test_vercel_entry_point(self):
        status, _, body = self.call("GET", "/register")
        self.assertEqual(status, "200 OK"); self.assertIn("Create account", body)
        status, headers, _ = self.call("POST", "/login", b"email=member%40x.com&password=password123")
        self.assertEqual(status, "303 See Other")
        sid = headers["Set-Cookie"].split(";")[0]
        self.assertIn("Member prices shown", self.call("GET", "/", cookie=sid)[2])
        self.assertEqual(self.call("GET", "/admin", cookie=sid)[0], "403 Forbidden")


class Http(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = app.ThreadingHTTPServer(("127.0.0.1", 0), app.H)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.secret = product("secret-sku", 1000, 400, 50, 1)

    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def client(self, email=None, pw="password123"):
        op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        if email: self.post(op, "/login", {"email": email, "password": pw})
        return op

    def get(self, op, path):
        try: r = op.open(self.base + path); return r.status, r.read().decode()
        except urllib.error.HTTPError as ex: return ex.code, ex.read().decode()

    def post(self, op, path, data, csrf_from=None):
        if csrf_from: data["csrf"] = re.search(r'name="csrf" value="([^"]+)"', self.get(op, csrf_from)[1]).group(1)
        try: r = op.open(self.base + path, urllib.parse.urlencode(data).encode()); return r.status, r.read().decode()
        except urllib.error.HTTPError as ex: return ex.code, ex.read().decode()

    def test_join_pay_approve_order(self):
        me, staff = self.client(), self.client("staff@x.com")
        body = self.post(me, "/register", {"name": "Nia", "email": "nia@x.com", "password": "password123",
                                           "phone": "+1 619 555 0150", "address": "7 Pine St"})[1]
        ref = re.search(r"APP-(\d+)", body).group(1)
        self.assertIn("Bank of Test, acct 123", body)  # pay page shown right after joining
        shop = self.get(me, "/")[1]
        self.assertNotIn("Secret-Sku", shop); self.assertNotIn('name="q', shop)  # no ordering yet
        self.assertIn(f"APP-{ref}", self.get(staff, "/admin")[1])  # shows on dashboard as waiting
        self.assertEqual(self.post(staff, f"/admin/accounts/{ref}", {"action": "approve"}, csrf_from="/admin")[0], 400)
        self.post(staff, f"/admin/accounts/{ref}", {"action": "approve", "deposit_ref": "TX-123", "back": "/admin"}, csrf_from="/admin")
        self.assertIn("Secret-Sku", self.get(me, "/")[1])
        body = self.post(me, "/order", {f"q{self.secret}": "2", "name": "Nia", "phone": "+1 619 555 0150",
                                        "address": "7 Pine St"}, csrf_from="/")[1]
        oid = re.search(r"Order #(\d+) placed", body).group(1)
        dash = self.get(staff, "/admin")[1]
        self.assertIn(f'data-copy="m{oid}"', dash)  # copy button for the driver message
        self.assertIn(f"#ORD-{oid}", dash)
        self.post(staff, f"/admin/accounts/{ref}", {"action": "revoke"}, csrf_from="/admin")
        self.assertNotIn("Secret-Sku", self.get(me, "/")[1])  # access ends immediately
        self.assertIn("deposit TX-123", self.get(staff, f"/admin/accounts/{ref}")[1])

    def test_staff_gives_logins_and_resets_passwords(self):
        staff = self.client("staff@x.com")
        self.post(staff, "/admin/accounts", {"kind": "member", "name": "Walk In", "email": "walkin@x.com", "password": "temppass123",
                                             "phone": "+1 619 555 0160", "deposit_ref": "CASH-1"}, csrf_from="/admin")
        walkin = self.client("walkin@x.com", "temppass123")
        self.assertIn("Secret-Sku", self.get(walkin, "/")[1])  # active immediately
        self.post(staff, "/admin/accounts", {"kind": "staff", "name": "Ed", "email": "ed@x.com", "password": "edpass12345",
                                             "phone": "+1 619 555 0161"}, csrf_from="/admin")
        self.assertEqual(self.get(self.client("ed@x.com", "edpass12345"), "/admin")[0], 200)
        uid = C.execute("SELECT id FROM users WHERE email='walkin@x.com'").fetchone()["id"]
        self.post(staff, f"/admin/accounts/{uid}", {"action": "password", "password": "newpass12345"}, csrf_from="/admin")
        self.assertNotIn("Secret-Sku", self.get(walkin, "/")[1])  # old session ended
        self.assertIn("Secret-Sku", self.get(self.client("walkin@x.com", "newpass12345"), "/")[1])

    def get_raw(self, op, path):
        try: r = op.open(self.base + path); return r.status, r.headers["Content-Type"], r.read()
        except urllib.error.HTTPError as ex: return ex.code, None, b""

    def test_product_photos_follow_product_visibility(self):
        staff, member, visitor = self.client("staff@x.com"), self.client("member@x.com"), self.client()
        for sku, members_only in (("pic-pub", ""), ("pic-mem", "on")):
            data = {"sku": sku, "name": sku.title(), "retail": "10", "wholesale": "6", "stock": "5", "active": "on", "image_data": JPEG}
            if members_only: data["wholesale_only"] = "on"
            self.post(staff, "/admin/products", data, csrf_from="/admin")
        pub, mem = (C.execute("SELECT image_id FROM products WHERE sku=?", (s,)).fetchone()["image_id"] for s in ("pic-pub", "pic-mem"))
        self.assertTrue(pub and mem)
        self.assertEqual(self.get_raw(visitor, f"/img/{pub}")[:2], (200, "image/jpeg"))
        self.assertIn(f'src="/img/{pub}"', self.get(visitor, "/")[1])  # shop grid shows it
        self.assertEqual(self.get_raw(visitor, f"/img/{mem}")[0], 404)  # members-only photo stays hidden
        self.assertEqual(self.get_raw(member, f"/img/{mem}")[0], 200)
        pid = C.execute("SELECT id FROM products WHERE sku='pic-pub'").fetchone()["id"]
        self.post(staff, f"/admin/products/{pid}", {"sku": "pic-pub", "name": "Pic-Pub", "retail": "10", "wholesale": "6",
                                                   "stock": "5", "active": "on", "image_data": JPEG}, csrf_from="/admin")
        C.conn.rollback()
        self.assertIsNone(C.execute("SELECT id FROM images WHERE id=?", (pub,)).fetchone())  # replaced photo is deleted
        body = self.post(staff, "/admin/products", {"sku": "bad", "name": "Bad", "retail": "1", "wholesale": "1", "stock": "1",
                                                    "image_data": "data:image/jpeg;base64," + base64.b64encode(b"<svg>").decode()}, csrf_from="/admin")[1]
        self.assertIn("isn&#x27;t a readable image", body)
        C.conn.rollback()

    def test_transfer_receipt_is_staff_only_and_marks_paid(self):
        staff, member = self.client("staff@x.com"), self.client("member@x.com")
        oid = app.place_order(C, user(MEMBER), {self.secret: 1}, *ADDR)
        body = self.post(staff, f"/admin/orders/{oid}/receipt", {"receipt_data": JPEG}, csrf_from="/admin")[1]
        C.conn.rollback()
        o = C.execute("SELECT payment, receipt_image_id FROM orders WHERE id=?", (oid,)).fetchone()
        self.assertEqual(o["payment"], "paid_transfer")
        self.assertIn(f'src="/img/{o["receipt_image_id"]}"', body)
        self.assertEqual(self.get_raw(staff, f"/img/{o['receipt_image_id']}")[0], 200)
        self.assertEqual(self.get_raw(member, f"/img/{o['receipt_image_id']}")[0], 404)
        self.assertEqual(self.get_raw(self.client(), f"/img/{o['receipt_image_id']}")[0], 404)
        self.assertIn("order.receipt", self.get(staff, "/admin/audit")[1])
        C.conn.rollback()

    def test_receipts_keep_latest_and_expire(self):
        staff = self.client("staff@x.com")
        oid = app.place_order(C, user(MEMBER), {self.secret: 1}, *ADDR)
        self.post(staff, f"/admin/orders/{oid}/receipt", {"receipt_data": JPEG}, csrf_from="/admin")
        C.conn.rollback(); first = C.execute("SELECT receipt_image_id AS r FROM orders WHERE id=?", (oid,)).fetchone()["r"]
        self.post(staff, f"/admin/orders/{oid}/receipt", {"receipt_data": JPEG}, csrf_from="/admin")
        C.conn.rollback(); second = C.execute("SELECT receipt_image_id AS r FROM orders WHERE id=?", (oid,)).fetchone()["r"]
        self.assertNotEqual(first, second)
        self.assertIsNone(C.execute("SELECT id FROM images WHERE id=?", (first,)).fetchone())  # replaced one is gone
        with C: C.execute("UPDATE images SET created_at=? WHERE id=?", (app.now() - (app.RECEIPT_DAYS + 1) * 86400, second))
        self.get(staff, "/admin")  # opening the dashboard runs the cleanup
        C.conn.rollback()
        self.assertIsNone(C.execute("SELECT id FROM images WHERE id=?", (second,)).fetchone())
        o = C.execute("SELECT payment, receipt_image_id FROM orders WHERE id=?", (oid,)).fetchone()
        self.assertEqual((o["payment"], o["receipt_image_id"]), ("paid_transfer", None))  # payment record stays
        self.assertIn("receipt deleted after", self.get(staff, "/admin/audit")[1])
        C.conn.rollback()

    def test_csv_exports(self):
        staff = self.client("staff@x.com")
        with C: C.execute("UPDATE users SET name='=HYPERLINK(1)' WHERE id=?", (PENDING,))
        for name in app.EXPORTS:
            status, ctype, raw = self.get_raw(staff, f"/admin/export/{name}.csv")
            self.assertEqual((status, ctype), (200, "text/csv; charset=utf-8"), name)
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"), name)  # BOM so Excel reads it as UTF-8
        members = self.get_raw(staff, "/admin/export/members.csv")[2].decode("utf-8-sig")
        self.assertIn("'=HYPERLINK(1)", members)  # formula neutralised
        self.assertNotIn(user(MEMBER)["pw"], members)  # password hashes never leave the database
        self.assertNotIn("pw", members.splitlines()[0].split(","))
        self.assertEqual(self.get_raw(self.client("member@x.com"), "/admin/export/orders.csv")[0], 403)
        self.assertIn("Image storage", self.get(staff, "/admin/export")[1])
        with C: C.execute("UPDATE users SET name='Pete' WHERE id=?", (PENDING,))

    def test_order_form_map(self):
        member = self.client("member@x.com")
        r = member.open(self.base + "/"); csp = r.headers["Content-Security-Policy"]; page = r.read().decode()
        for want in ('id="map"', 'integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="', 'name="lat"', 'id="address"'):
            self.assertIn(want, page)
        for want in ("https://tile.openstreetmap.org", "connect-src 'self' https://nominatim.openstreetmap.org", "script-src 'self' https://unpkg.com"):
            self.assertIn(want, csp)
        self.assertNotIn('id="map"', self.get(self.client(), "/")[1])  # visitors don't get the order form
        base = {f"q{self.secret}": "1", "name": "Sam", "phone": "+1 619 555 0102", "address": "2 Main St"}
        body = self.post(member, "/order", {**base, "lat": "abc", "lng": "1"}, csrf_from="/")[1]
        self.assertIn("The map pin is invalid", body)
        body = self.post(member, "/order", {**base, "lat": "32.7", "lng": "-117.1"}, csrf_from="/")[1]
        oid = re.search(r"Order #(\d+) placed", body).group(1)
        C.conn.rollback()
        self.assertEqual(C.execute("SELECT lat FROM orders WHERE id=?", (oid,)).fetchone()["lat"], 32.7)
        self.assertIn('value="32.700000"', self.get(member, "/")[1])  # next order starts at the last pin
        body = self.post(member, "/order", {**base, "address": "2 Main St, side door", "lat": "32.7", "lng": "-117.1",
                                            "pin_address": "2 Main Street, San Diego"}, csrf_from="/")[1]
        self.assertIn("2 Main St, side door", body); self.assertIn("Map: 2 Main Street, San Diego", body)  # member sees both
        C.conn.rollback()

    def test_only_staff_can_send_large_uploads(self):
        big = {"notes": "x" * 200_000}
        self.assertEqual(self.post(self.client("member@x.com"), "/order", big, csrf_from="/")[0], 413)
        self.assertNotEqual(self.post(self.client("staff@x.com"), f"/admin/orders/999999/receipt", big, csrf_from="/admin")[0], 413)

    def test_admin_is_staff_only(self):
        self.assertIn("Log in", self.get(self.client(), "/admin")[1])
        member = self.client("member@x.com")
        self.assertEqual(self.get(member, "/admin")[0], 403)
        self.assertEqual(self.post(member, f"/admin/accounts/{PENDING}", {"action": "approve", "deposit_ref": "x"},
                                   csrf_from="/")[0], 403)

    def test_post_without_csrf_is_rejected(self):
        self.assertEqual(self.post(self.client("member@x.com"), "/order", {f"q{self.secret}": "1"})[0], 403)

    def test_every_page_renders(self):
        staff = self.client("staff@x.com")
        for p in ["/", "/account", "/admin", "/admin/orders", "/admin/orders?status=new", "/admin/accounts",
                  f"/admin/accounts/{MEMBER}", "/admin/products", "/admin/drivers", "/admin/audit", "/admin/export", "/app.js"]:
            self.assertEqual(self.get(staff, p)[0], 200, p)
        for p in ["/", "/register", "/login"]: self.assertEqual(self.get(self.client(), p)[0], 200, p)


if __name__ == "__main__":
    unittest.main()
